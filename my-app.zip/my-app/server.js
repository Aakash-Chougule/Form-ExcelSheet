const express = require('express');
const fs = require('fs').promises;
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_FILE = path.join(__dirname, 'data.json');

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

async function readData() {
  try {
    const txt = await fs.readFile(DATA_FILE, 'utf8');
    return JSON.parse(txt || '[]');
  } catch (err) {
    if (err.code === 'ENOENT') return [];
    throw err;
  }
}

async function writeData(data) {
  await fs.writeFile(DATA_FILE, JSON.stringify(data, null, 2), 'utf8');
}

app.get('/entries', async (req, res) => {
  const data = await readData();
  res.json(data);
});

app.get('/entries/:id', async (req, res) => {
  const data = await readData();
  const entry = data.find(e => e.id === req.params.id);
  if (!entry) return res.status(404).json({ message: 'Not found' });
  res.json(entry);
});

app.post('/entries', async (req, res) => {
  const newEntry = req.body || {};
  newEntry.id = Date.now().toString();
  newEntry.createdAt = new Date().toISOString();

  const data = await readData();
  data.push(newEntry);
  await writeData(data);

  res.json({ message: 'Saved', entry: newEntry });
});

app.put('/entries/:id', async (req, res) => {
  const id = req.params.id;
  const update = req.body || {};
  const data = await readData();
  const idx = data.findIndex(e => e.id === id);
  if (idx === -1) return res.status(404).json({ message: 'Not found' });

  data[idx] = { ...data[idx], ...update, updatedAt: new Date().toISOString() };
  await writeData(data);
  res.json({ message: 'Updated', entry: data[idx] });
});

app.delete('/entries/:id', async (req, res) => {
  const id = req.params.id;
  const data = await readData();
  const newData = data.filter(e => e.id !== id);
  if (newData.length === data.length) return res.status(404).json({ message: 'Not found' });
  await writeData(newData);
  res.json({ message: 'Deleted' });
});

app.get('/data.json', (req, res) => {
  res.sendFile(DATA_FILE);
});

app.listen(PORT, () => {
  console.log(`✅ Server running at http://localhost:${PORT}`);
});
